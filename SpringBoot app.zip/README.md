# BFHL Java Qualifier (Shortcut Submission)

This repository contains my solution.

## Contents
- **solution.sql** → final SQL query
- **submission.json** → sample submission payload
- **dummy.jar** → placeholder JAR file (since time was limited)

## Note
Due to time constraints, instead of a full Spring Boot project,
I am submitting the SQL solution + webhook request format + dummy JAR.
